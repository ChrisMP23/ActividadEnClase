/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 * Class: SingletonConexionBD
 * 
 * @version: 0.1
 *  
 * @since: 26/08/2019
 * 
 * Fecha de Modificación:
 * 
 * @author: Yanvier Tamara Meriño
 * 
 * Copyright: CECAR
 */

package edu.cecar.componentes.singletons;

import edu.cecar.componentes.baseDeDatos.ConectarMySQL;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
*
* Singleton que devuelve la conexion a una base de datos
*
*/

//Lazy(Perezoso)
public class SingletonConexionDB {

   private static Connection connection;
   private static Connection connection1 = new ConectarMySQL(null, null, null, null, null).getConnection();
   
   public static Connection getinstance() throws IOException{
       
       if (connection == null){
           
           Properties properties = new Properties();
           
           try {
               properties.load(new FileInputStream("recursos/Conexion.properties"));
               
               connection = new ConectarMySQL(properties.getProperty("host"), properties.getProperty("baseDatos"), properties.getProperty("port"),
                       properties.getProperty("usuario"), properties.getProperty("password")).getConnection();
               
               
           } catch (FileNotFoundException ex) {
               Logger.getLogger(SingletonConexionDB.class.getName()).log(Level.SEVERE, null, ex);
           }
           
           
           
       }
       return connection;
       
   }
   
   //Eager(ancioso)
   
   public Connection getinstance1(){
       return connection1;
       
   }
   
}

